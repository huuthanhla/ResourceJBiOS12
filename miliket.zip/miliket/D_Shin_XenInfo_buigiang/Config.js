var time = true; // True for "24h".
var padzero = true; 
